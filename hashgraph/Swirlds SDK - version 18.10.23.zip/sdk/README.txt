Swirlds SDK README

For info about this SDK, open the file docs/index.html in a browser.
