package com.swirlds.demo.file.fileexplorer;

import java.util.List;

import com.swirlds.fs.Header;;

interface Model {
	List<String> ls(String path);

	Header loadHeader(String path);

	byte[] fcNamei(String path);

	boolean isDir(String path);

	void mkdir(String path);

	void cp(String srcpath, String destpath);

	void rm(String path);

	void exportRec(String entity, String physDest);

	void importRec(String phys, String dest);
}