package com.swirlds.demo.file.fileexplorer;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;

import com.swirlds.fs.FCFileSystem;
import com.swirlds.fs.Header;

public class RealModel implements Model {
	FCFileSystem fs;

	public RealModel(FCFileSystem fs) {
		this.fs = fs;
	}

	public List<String> ls(String path) {
		return Arrays.asList(fs.ls(path));
	}

	public Header loadHeader(String path) {
		return fs.loadHeader(path);
	}

	public byte[] fcNamei(String path) {
		return fs.fcNamei(path);
	}

	public boolean isDir(String path) {
		return fs.isDir(path);
	}

	public void mkdir(String path) {
		Instant now = Instant.now();
		fs.mkdir(path, now.toEpochMilli(), now.plus(365, ChronoUnit.DAYS).toEpochMilli(),
				now.plus(365, ChronoUnit.DAYS).getNano(), null);
	}

	public void cp(String srcpath, String destpath) {
	}

	public void rm(String path) {
	}

	public void exportRec(String entity, String physDest) {
		fs.exportRec(entity, physDest);
	}

	public void importRec(String phys, String dest) {
	}
}
