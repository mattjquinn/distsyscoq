#!/bin/bash
cd "`dirname "$0"`"

rm    *.pfx        2> /dev/null
rm    -rf unused   2> /dev/null